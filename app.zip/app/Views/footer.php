<!-- footer content -->
<footer>
    <div class="pull-right">
        SATAHI - Bank Sampah <a href="https://kec.batangtoru.id/">Kecamatan Batang Toru</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->